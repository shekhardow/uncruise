<?php echo $__env->make('admin/common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(@$title != 'Login'): ?>
    <?php echo $__env->make('admin/common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php endif; ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldSection(); ?>
<?php echo $__env->make('admin/common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\uncruise\resources\views/admin/layout.blade.php ENDPATH**/ ?>