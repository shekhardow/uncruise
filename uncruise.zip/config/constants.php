<?php 
	return [
		'social_link'      => array('Facebook','Instagram','Youtube','Telegram','Linkedin'),
		'pagination'       => ['perpage' => 8],
	];
?>